#include "sys.h"//���ߣ��������  qq:624668529
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "key.h"
#include "mavlink_avoid_errors.h"
#include "mavlink_usart_fifo.h"
#include "open_tel_mavlink.h"
#include "timer.h"
//#include "stm32f10x.h"

//ALIENTEK ̽����STM32F407������ ʵ��4
//����ͨ��ʵ�� -�⺯���汾
//����֧�֣�www.openedv.com
//�Ա����̣�http://eboard.taobao.com
//�������������ӿƼ����޹�˾  
//���ߣ�����ԭ�� @ALIENTEK
//mavlink_system_t mavlink_system;
#define UART_TX_BUFFER_SIZE        255
#define UART_RX_BUFFER_SIZE        255
extern fifo_t uart_rx_fifo, uart_tx_fifo;
extern uint8_t uart_tx_buf[UART_TX_BUFFER_SIZE], uart_rx_buf[UART_RX_BUFFER_SIZE];
extern int a,b,c,d;


int main(void)
{ 
	mavlink_command_long_t com = { 0 };
	mavlink_set_mode_t set_mode={0};
	mavlink_command_long_t take_off_local={0};
	mavlink_command_long_t take_off={0};
	mavlink_command_long_t land={0};
	mavlink_command_long_t ROI={0};
	mavlink_set_position_target_local_ned_t set_position={0};
	/*mavlink_control_system_state_t control={0};
	control.airspeed=-1;
	control.x_acc=1;
	control.x_vel=2;
	control.x_pos=3;
	control.y_acc=1;
	control.y_vel=2;
	control.y_pos=3;
	control.z_acc=1;
	control.z_vel=2;
	control.z_pos=3;*/
	
	set_position.target_system=1;
	set_position.target_component=0;
	set_position.coordinate_frame=MAV_FRAME_LOCAL_NED;
	set_position.type_mask=4039;
	set_position.time_boot_ms=0;
	set_position.afx=0;
	set_position.vx=8;
	set_position.x=0;
	set_position.afy=0;
	set_position.vy=8;
	set_position.y=0;
	set_position.afz=0;
	set_position.vz=8;
	set_position.z=0;
	
	com.target_system    = 1;
	com.target_component = 0;
	com.command          = MAV_CMD_COMPONENT_ARM_DISARM;
	com.confirmation     = true;
	com.param1           = 1; // flag >0.5 => start, <0.5 => stop
	
	
	set_mode.target_system=1;
	set_mode.base_mode=MAV_MODE_FLAG_CUSTOM_MODE_ENABLED;
	set_mode.custom_mode=4;

	take_off_local.target_system=1;
	take_off_local.target_component=0;
	take_off_local.confirmation=true;
	take_off_local.command=MAV_CMD_NAV_TAKEOFF_LOCAL;
	take_off_local.param1=  0;
	take_off_local.param3=30;
	take_off_local.param4=0;
	take_off_local.param5=0;
	take_off_local.param6=0;
	take_off_local.param7=5;
	
	ROI.target_system=1;
	ROI.target_component=0;
	ROI.confirmation=true;
	ROI.command=MAV_CMD_DO_SET_SERVO;
	ROI.param1=1;
	ROI.param2=1010;
	ROI.param3=0;
	ROI.param4=0;
	ROI.param5=0;
	ROI.param6=0;
	ROI.param7=0;
	
	take_off.target_system=1;
	take_off.target_component=0;
	take_off.confirmation=true;
	take_off.command=MAV_CMD_NAV_TAKEOFF;
	take_off.param1= 4000;
	take_off.param4=0;
	take_off.param5=0;
	take_off.param6=0;
	take_off.param7=1;
	
	land.target_system=1;
	land.command=MAV_CMD_NAV_LAND;
	land.confirmation=true;
	land.target_component=0;
	land.param5=0;
	land.param6=0;
	land.param7=0;
	
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	delay_init();		//��ʱ��ʼ�� 
	uart_init(57600);	//���ڳ�ʼ��������Ϊ115200
	LED_Init();		  		//��ʼ����LED���ӵ�Ӳ���ӿ�  
	TIM3_Int_Init(4999,7199);//10Khz�ļ���Ƶ�ʣ�������5000Ϊ500ms 
	
	fifo_init(&uart_tx_fifo, uart_tx_buf, UART_TX_BUFFER_SIZE);	
	fifo_init(&uart_rx_fifo, uart_rx_buf, UART_RX_BUFFER_SIZE);
	while(1)
	{
		mavlink_msg_command_long_send_struct(MAVLINK_COMM_0,&com);
		delay_ms(500);
		//USART_SendData(USART2,a);
		//while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
		if(a==1)
		{
			USART_SendData(USART2,b);
			while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
			if(b!=1&&c==1)
			{
				
			}
			delay_ms(500);
			mavlink_msg_command_long_send_struct(MAVLINK_COMM_0,&take_off);
			if(c==1)
			{
				USART_SendData(USART2,8);
				while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
				TIM3->CR1|=0x01;    //ʹ�ܶ�ʱ��3 ʹ��TIMx	
			}
			if(d>=10)
			{
				mavlink_msg_set_mode_send_struct(MAVLINK_COMM_0,&set_mode);
				USART_SendData(USART2,9);
				while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
			}
			if(d>=20&&b==1)
			{
				mavlink_msg_command_long_send_struct(MAVLINK_COMM_0,&ROI);
				//mavlink_msg_set_position_target_local_ned_send_struct(MAVLINK_COMM_0,&set_position);
				USART_SendData(USART2,10);
				while(USART_GetFlagStatus(USART2,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
				//mavlink_msg_command_long_send_struct(MAVLINK_COMM_0,&land);
			}
		}
		//mavlink_msg_optical_flow_send_struct(MAVLINK_COMM_0,&flow);
		update();
	}
}


